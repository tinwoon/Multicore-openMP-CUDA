﻿#include <core.hpp>
#include <highgui.hpp>
#include <imgproc.hpp>
#include <opencv.hpp>
#include <cstdio>
#include <cmath>
#include "DS_timer.h"
#include "DS_definitions.h"

using namespace cv;
using namespace std;

const int thresh = 100;
const int descriptor_Size = 5;
const float MinNCC = 0.9;

//해리스 코너를 사용하여 코너점을 찾습니다.
vector<KeyPoint> find_points(Mat src, int block_size = 5, double k = 0.05);

//코너점의 방향을 계산합니다.
vector<double> ori_points(Mat src, vector<KeyPoint> keyPoints);

//이미지 패치를 회전합니다.
Mat rotation(Mat src, double angle);

//코너점을 중심으로한 descriptor를 구합니다.
vector<Mat> points_descriptor(Mat src, vector<KeyPoint> points, vector<double> orientation);

// 매칭을 구합니다.
vector<DMatch> feature_match(vector<Mat> des1, vector<Mat> des2);



int main() {

	DS_timer timer(2);
	timer.setTimerName(0, (char*)"Serial Algorithm");
	timer.setTimerName(1, (char*)"Parallel Algorithm");

	//** 1. Serial code **//
	timer.onTimer(0);

	Mat srcImage1 = imread("img1.jpg", IMREAD_COLOR);
	Mat srcImage2 = imread("img2.jpg", IMREAD_COLOR);

	if (srcImage1.empty() || srcImage2.empty()) {
		printf("이미지를 찾을 수 없음\n");
		return -1;
	}

	vector<KeyPoint> keyPoint1 = find_points(srcImage1, 5, 0.04);
	vector<KeyPoint> keyPoint2 = find_points(srcImage2, 5, 0.04);

	
	vector<double> ori1 = ori_points(srcImage1, keyPoint1);
	vector<double> ori2 = ori_points(srcImage2, keyPoint2);
	
	vector<Mat> des1 = points_descriptor(srcImage1, keyPoint1, ori1);
	vector<Mat> des2 = points_descriptor(srcImage2, keyPoint2, ori2);

	vector<DMatch> match_result = feature_match(des1, des2);
	
	Mat matching_img;
	drawMatches(srcImage1, keyPoint1, srcImage2, keyPoint2, match_result, matching_img, Scalar::all(-1), Scalar::all(-1), std::vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
	imshow("matching_img", matching_img);
	
	timer.offTimer(0);



	//** 2. Parallel code **//
	timer.onTimer(1);



	timer.offTimer(1);



	//** 3. Result checking code **//
	bool isCorrect = true;
	if (!isCorrect) {
		printf("Results are not matched :(\n");
	}
	else {
		printf("\nResults are matched! :)\n");
	}
	timer.printTimer();

	waitKey();
	
	return 0;
}

vector<KeyPoint> find_points(Mat src, int block_size, double k) {

	Mat dst, dst_norm, dst_norm_scaled;
	cvtColor(src, dst, COLOR_BGR2GRAY);
	cornerHarris(dst, dst, block_size, 3, k, BORDER_DEFAULT);
	normalize(dst, dst_norm, 0, 255, NORM_MINMAX, CV_32FC1, Mat());
	convertScaleAbs(dst_norm, dst_norm_scaled);

	vector<KeyPoint> corners;
	for (int j = 0; j < dst_norm.rows; j++) {
		for (int i = 0; i < dst_norm.cols; i++) {
			if ((int)dst_norm.at<float>(j, i) > thresh) {
				corners.push_back(KeyPoint(i, j, 5));

			}
		}
	}

	return corners;
}

//코너점의 방향을 계산합니다.
vector<double> ori_points(Mat src, vector<KeyPoint> keyPoints) {
	vector<double> orientation;

	return orientation;
}

//이미지 패치를 회전합니다.
Mat rotation(Mat src, double angle) {
	// 이미지의 너비, 높이
	int w = src.rows;
	int h = src.cols;

	// 이미지의 중심 좌표
	int cX = w / 2;
	int cY = h / 2;

	// 이미지의 중심을 기준으로 회전 매트릭스, Scale = 1
	Mat rotation_matrix = getRotationMatrix2D(Point2f(cX, cY), -angle, 1.0);

	// data[0, 0] = scale⋅cosangle, data[0, 1] = scale⋅sinangle
	int cos = abs(rotation_matrix.data[0, 0]);
	int sin = abs(rotation_matrix.data[0, 1]);

	int newWidth = int((h * sin) + (w * cos));
	int newHeight = int((h * cos) + (w * sin));

	rotation_matrix.data[0, 2] += (newWidth / 2) - cX;
	rotation_matrix.data[1, 2] += (newHeight / 2) - cY;

	Mat imgRotated;
	warpAffine(src, imgRotated, rotation_matrix, Size(newWidth, newHeight));

	return imgRotated;
}

//코너점을 중심으로한 descriptor를 구합니다.
vector<Mat> points_descriptor(Mat src, vector<KeyPoint> points, vector<double> orientation) {
	/*
	if (points.size() != orientation.size()) {
		throw exception("descriptor::point count not same");
	}*/
	vector<Mat> descriptor;

	Mat dst;
	cvtColor(src, dst, COLOR_BGR2GRAY);

	for (int i = 0; i < points.size(); i++) {
		int x = max((int)points[i].pt.x - 2, 0);
		int y = max((int)points[i].pt.y - 2, 0);
		x = min(x, src.rows - 5);
		y = min(y, y = src.cols - 5);

		Rect rect(x, y, 5, 5);
		/*
		Mat temp = rotation(dst(rect), orientation[i]);

		descriptor.push_back(temp);
		*/

		descriptor.push_back(dst(rect));
	}
	return descriptor;
}

// 매칭을 구합니다.
vector<DMatch> feature_match(vector<Mat> des1, vector<Mat> des2) {
	vector<DMatch> match;

	for (int i = 0; i < des1.size(); i++) {
		float MaxNCC = -1;
		int MaxNumber = -1;

		for (int j = 0; j < des2.size(); j++) {
			if (des1[i].channels() != des2[j].channels()) {
				throw exception("NCC::Image chanel not same");
			}

			int nSum1 = 0, nSum2 = 0;
			int nSqr1 = 0, nSqr2 = 0;

			unsigned char* des1_ptr = (unsigned char*)des1[i].data;
			unsigned char* des2_ptr = (unsigned char*)des2[j].data;
			int channels = des1[i].channels();


			for (int r = 0; r < descriptor_Size; r++) {
				for (int c = 0; c < descriptor_Size; c++) {
					for (int l = 0; l < channels; l++) {
						int t1 = des1_ptr[(r * des1[i].cols * channels) + (c * channels) + l];
						int t2 = des2_ptr[(r * des2[j].cols * channels) + (c * channels) + l];

						nSum1 += t1;
						nSum2 += t2;
						nSqr1 += (int)pow(t1, 2);
						nSqr2 += (int)pow(t2, 2);
					}
				}
			}
			
			int nPixels = descriptor_Size * descriptor_Size * channels;          //픽셀의 수
			float fMean1 = (float)nSum1 / (float)nPixels;                       //des1의 평균
			float fMean2 = (float)nSum2 / (float)nPixels;                       //des1의 평균
			float fVar1 = sqrt(((float)nSqr1 / (float)nPixels) - pow(fMean1, 2));  //des1의 표준편차
			float fVar2 = sqrt(((float)nSqr2 / (float)nPixels) - pow(fMean2, 2));  //des2의 표준편차

			float fSumNCC = 0.0f;

			for (int r = 0; r < descriptor_Size; r++) {
				for (int c = 0; c < descriptor_Size; c++) {
					for (int l = 0; l < channels; l++) {
						fSumNCC += ((float)des1_ptr[(r * des1[i].cols * channels) + (c * channels) + l] - fMean1) *
							((float)des2_ptr[(r * des2[j].cols * channels) + (c * channels) + l] - fMean2);
					}
				}
			}

			float NCC = fSumNCC / (fVar1 * fVar2);
			NCC /= nPixels;
			NCC = abs(NCC);

			//printf("(%d,%d) : %lf\n", i, j, NCC);

			if (MaxNCC < NCC) {
				MaxNCC = NCC;
				MaxNumber = j;
			}
		}
		if (MaxNCC > MinNCC) {
			match.push_back(DMatch(i, MaxNumber, MaxNCC));
		}
	}
	return match;
}